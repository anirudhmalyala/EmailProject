In this project, we generated the login, registration , forgot username, forgot password forms.

When you click on forgot password or username, you will be redirected to your email where you have to set new password.


	THE NECESSARY CHANGES BEFORE RUNNING THIS APPLICATION:

	a)	Change your Oracle password at
				i)		EmailDAO.java				[line no:	20]
				ii)	conf_submission.jsp		[line no:	115]
				iii)	newpassword.jsp			[line no:	110]

	b)	Give your google email and password in "web.xml"

	c)		Change your IP Address and Port Number at 
				i)		conf_submission.jsp		[line no:	139]
				ii)	EmailUtility.java				[line no:	53]

				
				
									..author@anirudhmalyala_161012
									..author@sowjanyadoddapneni_161010
									..author@bhavyareddy
									