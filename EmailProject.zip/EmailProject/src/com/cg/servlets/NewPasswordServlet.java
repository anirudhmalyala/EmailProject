package com.cg.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.servlets.dao.EmailDAO;


/**
 * Servlet implementation class NewPasswordServlet
 */
@WebServlet("/NewPasswordServlet")
public class NewPasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String confirmpassword = request.getParameter("confirmpassword");
		
		if(password.equals(confirmpassword)) {
			EmailDAO dao = new EmailDAO();
		int n = dao.createNewPassword(email, password);
		if (n > 0) {
				out.println("<center><b style='color:green; font-size:18px; font-family:verdana;'>Update Successful.</b></center><br>");
				RequestDispatcher requestDispatcher = request.getRequestDispatcher("login.jsp");
				requestDispatcher.include(request, response);
			}else {
				response.sendRedirect("forgotpass.jsp?emsg=Something might went wrong");
			}
		}
		else {
			out.println("<center><b style='color:red; font-size:18px; font-family:verdana;'>Both password fields should be same.</center>");
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("newpassword.jsp");
			requestDispatcher.include(request, response);
		}
		
		
	}
		
	
}
