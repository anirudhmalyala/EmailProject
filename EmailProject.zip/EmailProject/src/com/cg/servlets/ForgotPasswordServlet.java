package com.cg.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.servlets.dao.EmailDAO;

/**
 * Servlet implementation class ForgotPasswordServlet
 */
@WebServlet("/ForgotPasswordServlet")
public class ForgotPasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String username = request.getParameter("username");
		String email = request.getParameter("email");
		
		EmailDAO dao = new EmailDAO();
		boolean flag = dao.validatePassword(username, email);

			if(flag) {
			out.println("<center><p style='color:#FFFF00; font-size:18px; font-family:verdana;'>Your reset-link is sent to the given email id. Please check by 24 Hours or it will get expired.</p></center>");
			//ou.println();
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("conf_submission.jsp");
			requestDispatcher.include(request, response);
		}else {
			out.println("<center><b style='color:red; font-size:18px; font-family:verdana;'>Entered Username/Email ID is incorrect</b></center>");
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("forgotpassword.jsp");
			requestDispatcher.include(request, response);
		}

	}

}
